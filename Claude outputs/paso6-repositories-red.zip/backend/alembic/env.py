"""env.py de Alembic.

Lee `DATABASE_URL` de entorno (o `.env` vía python-dotenv, ya presente
desde el Paso 0) e importa el `Base.metadata` único de
`prime.identity.infrastructure.orm.models`. No hay una segunda fuente de
verdad del esquema: lo que ve Alembic es exactamente lo que ve la
aplicación en runtime.
"""
import os
from logging.config import fileConfig

from alembic import context
from dotenv import load_dotenv
from sqlalchemy import engine_from_config, pool

load_dotenv()

# Importa TODOS los modelos para que se registren en Base.metadata antes
# de que Alembic la lea. Basta con importar el módulo `models`.
from prime.identity.infrastructure.orm.base import Base  # noqa: E402
from prime.identity.infrastructure.orm import models  # noqa: E402,F401

config = context.config
config.set_main_option("sqlalchemy.url", os.environ["DATABASE_URL"])

if config.config_file_name is not None:
    fileConfig(config.config_file_name)

target_metadata = Base.metadata


def run_migrations_offline() -> None:
    url = config.get_main_option("sqlalchemy.url")
    context.configure(
        url=url,
        target_metadata=target_metadata,
        literal_binds=True,
        dialect_opts={"paramstyle": "named"},
        compare_type=True,
    )
    with context.begin_transaction():
        context.run_migrations()


def run_migrations_online() -> None:
    connectable = engine_from_config(
        config.get_section(config.config_ini_section, {}),
        prefix="sqlalchemy.",
        poolclass=pool.NullPool,
    )
    with connectable.connect() as connection:
        context.configure(
            connection=connection,
            target_metadata=target_metadata,
            compare_type=True,
        )
        with context.begin_transaction():
            context.run_migrations()


if context.is_offline_mode():
    run_migrations_offline()
else:
    run_migrations_online()
